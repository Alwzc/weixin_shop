module.exports = {
    name: "小程序",
    uniacid: "-1",
    acid: "-1",
    multiid: "0",
    version: "2.8.9",
    siteroot: "https://www.baidu.com/app/index.php",
    design_method: "3"
};